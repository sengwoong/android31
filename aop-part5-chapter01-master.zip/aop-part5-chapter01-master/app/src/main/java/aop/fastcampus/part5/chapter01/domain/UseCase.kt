package aop.fastcampus.part5.chapter01.domain

internal interface UseCase
