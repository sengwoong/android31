package aop.fastcampus.part5.chapter01.presentation.detail

enum class DetailMode {
    DETAIL, WRITE
}
