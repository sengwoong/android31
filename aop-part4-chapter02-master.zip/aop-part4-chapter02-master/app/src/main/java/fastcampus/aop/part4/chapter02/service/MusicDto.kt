package fastcampus.aop.part4.chapter02.service

data class MusicDto(
    val musics: List<MusicEntity>
)