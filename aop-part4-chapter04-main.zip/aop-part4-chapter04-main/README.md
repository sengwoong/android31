# aop-part4-chapter04 - OTT 앱 인트로 따라하기

# 목차
1. ScrollView에 모션 레이아웃 구현하기 1차
2. AppbarLayout을 이용해 헤더 애니메이션 구현하기
3. ScrollView에 모션 레이아웃 구현하기 2차
4. ScrollView 내 부족한 내용 추가 및 다듬기



## 결과 화면

| 결과 화면 |
| -------------------------------------- |
| ![결과 화면](https://user-images.githubusercontent.com/8112952/109826336-07971f00-7c7e-11eb-94fb-5dfa433f1da6.gif) |
