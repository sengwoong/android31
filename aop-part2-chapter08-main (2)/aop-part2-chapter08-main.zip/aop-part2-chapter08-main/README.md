# aop-part2-chapter08

## 목차
0. 인트로, 프로젝트 셋업
1. 기본 UI 구성하기
2. URL 로딩 기능 구현하기
3. 네비게이션 기능 구현하기
4. 완성도 높이기

## 결과화면
<img src="https://i.imgur.com/PxjdguS.png" width="400"/>
