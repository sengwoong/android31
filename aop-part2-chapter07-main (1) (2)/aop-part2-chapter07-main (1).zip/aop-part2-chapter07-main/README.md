# aop-part2-chapter07

## 목차
0. 인트로, 프로젝트 셋업
1. 기본 UI 구성하기
2. 권한 요청하기
3. 녹음 기능 구현하기
4. 완성도 높이기 - 오디오 시각화
5. 완성도 높이기 - 마무리

## 결과화면
|Screenshot1|Screenshot2|
|---|---|
|<img src="https://i.imgur.com/WUjmIC5.png"/>|<img src="https://i.imgur.com/CUbK9TT.png"/>|
