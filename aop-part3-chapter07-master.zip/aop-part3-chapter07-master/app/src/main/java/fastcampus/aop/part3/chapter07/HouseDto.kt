package fastcampus.aop.part3.chapter07

data class HouseDto(
    val items: List<HouseModel>
)