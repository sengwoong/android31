package fastcampus.aop.part4.chapter03

object Key {
    const val TMAP_API = "846fd0ff-fac4-4e07-9c7c-1950cc0131dd"
}
