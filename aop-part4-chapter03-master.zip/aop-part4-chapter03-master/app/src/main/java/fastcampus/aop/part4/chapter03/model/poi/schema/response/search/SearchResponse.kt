package fastcampus.aop.part4.chapter03.model.poi.schema.response.search

data class SearchResponse(
    val searchPoiInfo: SearchPoiInfo
)
