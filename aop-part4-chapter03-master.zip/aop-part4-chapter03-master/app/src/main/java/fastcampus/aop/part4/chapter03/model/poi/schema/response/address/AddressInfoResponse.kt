package fastcampus.aop.part4.chapter03.model.poi.schema.response.address

data class AddressInfoResponse(
    val addressInfo: AddressInfo
)
