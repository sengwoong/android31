package fastcampus.aop.part5.chapter06.data.api

object Url {
    const val SWEET_TRACKER_API_URL = "http://info.sweettracker.co.kr/"
}
