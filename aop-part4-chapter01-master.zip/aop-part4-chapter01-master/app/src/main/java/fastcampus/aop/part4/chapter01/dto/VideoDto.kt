package fastcampus.aop.part4.chapter01.dto

import fastcampus.aop.part4.chapter01.model.VideoModel

data class VideoDto(
    val videos: List<VideoModel>
)
